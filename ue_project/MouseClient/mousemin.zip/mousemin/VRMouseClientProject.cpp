// Copyright Epic Games, Inc. All Rights Reserved.

#include "VRMouseClientProject.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, VRMouseClientProject, "VRMouseClientProject" );
